import { useState } from "react"

import Sidebar from "./components/Sidebar"
import CompanySetupModal from "./components/CompanySetupModal"

import Dashboard from "./pages/Dashboard"
import Invoices from "./pages/Invoices"
import Purchases from "./pages/Purchases"
import Parties from "./pages/Parties"
import Vouchers from "./pages/Vouchers"
import Reports from "./pages/Reports"
import Ledgers from "./pages/Ledgers"
import Settings from "./pages/Settings"
import Stock from "./pages/Stock"
import StockLedger from "./pages/StockLedger"

export default function App() {

  /* ACTIVE PAGE */

  const [
    activePage,
    setActivePage
  ] = useState("dashboard")

  /* SELECTED STOCK ITEM */

  const [
    selectedStockItem,
    setSelectedStockItem
  ] = useState(null)

  /* COMPANY SETUP MODAL */

  const [

    showCompanySetup,

    setShowCompanySetup

  ] = useState(

    !localStorage.getItem(
      "billmitra-company"
    )
  )

  /* PAGE RENDERER */

  function renderPage() {

    switch (activePage) {

      /* DASHBOARD */

      case "dashboard":

        return <Dashboard />

      /* SALES */

      case "invoices":

        return <Invoices />

      /* PURCHASES */

      case "purchases":

        return <Purchases />

      /* PARTIES */

      case "parties":

        return <Parties />

      /* VOUCHERS */

      case "vouchers":

        return <Vouchers />

      /* REPORTS */

      case "reports":

        return <Reports />

      /* LEDGERS */

      case "ledgers":

        return <Ledgers />

      /* STOCK SUMMARY */

      case "stock":

        return (

          <Stock

            openLedger={(item) => {

              setSelectedStockItem(
                item
              )

              setActivePage(
                "stock-ledger"
              )
            }}

          />

        )

      /* STOCK LEDGER */

      case "stock-ledger":

        return (

          <StockLedger

            itemName={
              selectedStockItem
            }

            goBack={() =>
              setActivePage("stock")
            }

          />

        )

      /* SETTINGS */

      case "settings":

        return <Settings />

      /* DEFAULT */

      default:

        return <Dashboard />
    }
  }

  return (

    <div
      style={{

        display: "flex",

        minHeight: "100vh",

        background:
          "#eef2f7"
      }}
    >

      {/* COMPANY SETUP POPUP */}

      {

        showCompanySetup && (

          <CompanySetupModal

            onClose={() =>

              setShowCompanySetup(
                false
              )

            }

          />

        )
      }

      {/* SIDEBAR */}

      <Sidebar

        activePage={
          activePage
        }

        setActivePage={
          setActivePage
        }

      />

      {/* MAIN CONTENT */}

      <div
        style={{

          flex: 1,

          padding: "35px",

          overflowY: "auto"
        }}
      >

        {/* PAGE CONTAINER */}

        <div
          style={{

            background:
              "linear-gradient(to bottom right, #ffffff, #f8fafc)",

            borderRadius: "28px",

            padding: "35px",

            minHeight:
              "calc(100vh - 70px)",

            boxShadow:
              "0 12px 40px rgba(0,0,0,0.08)",

            border:
              "1px solid #e2e8f0"
          }}
        >

          {renderPage()}

        </div>

      </div>

    </div>
  )
}