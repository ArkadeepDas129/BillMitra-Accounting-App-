export default function InvoicePreview({
  invoiceData,
  items
}) {

  /* COMPANY DATA */

  const companyData =

    JSON.parse(

      localStorage.getItem(
        "billmitra-company"
      )

    ) || {}

  /* ITEM CALCULATIONS */

  function calculateItem(item) {

    const gross =

      Number(item.quantity) *

      Number(item.rate)

    const taxable =

      gross -

      Number(item.discount)

    const gstAmount =

      taxable *

      (
        Number(item.gstRate) / 100
      )

    const total =
      taxable + gstAmount

    return {

      gross,

      taxable,

      gstAmount,

      total
    }
  }

  /* TOTALS */

  const subtotal =

    items.reduce(

      (sum, item) =>

        sum +

        calculateItem(item)
          .taxable,

      0
    )

  const totalGST =

    items.reduce(

      (sum, item) =>

        sum +

        calculateItem(item)
          .gstAmount,

      0
    )

  const cgst =
    totalGST / 2

  const sgst =
    totalGST / 2

  const grandTotal =
    subtotal + totalGST

  return (

    <div className="preview-panel">

      <div className="invoice-paper">

        {/* HEADER */}

        <div className="invoice-header">

          <h1 className="invoice-main-title">

            TAX INVOICE

          </h1>

        </div>

        {/* COMPANY DETAILS */}

        <table className="invoice-table">

          <tbody>

            <tr>

              <td className="company-cell">

                <div className="company-name">

                  {

                    companyData.companyName

                    ||

                    "Your Company"
                  }

                </div>

                <div className="company-text">

                  GSTIN:
                  {" "}

                  {

                    companyData.gstin

                    ||

                    "-"
                  }

                </div>

                <div className="company-text">

                  {

                    companyData.address

                    ||

                    "No Address"
                  }

                </div>

                <div className="company-text">

                  {

                    companyData.state

                    ||

                    "-"
                  }

                </div>

                <div className="company-text">

                  Phone:
                  {" "}

                  {

                    companyData.phone

                    ||

                    "-"
                  }

                </div>

                <div className="company-text">

                  Email:
                  {" "}

                  {

                    companyData.email

                    ||

                    "-"
                  }

                </div>

              </td>

              {/* META */}

              <td className="meta-cell">

                <div className="meta-row">

                  <span>
                    Invoice No
                  </span>

                  <strong>

                    {
                      invoiceData.invoiceNo
                    }

                  </strong>

                </div>

                <div className="meta-row">

                  <span>
                    Dated
                  </span>

                  <strong>

                    {
                      invoiceData.invoiceDate
                    }

                  </strong>

                </div>

                <div className="meta-row">

                  <span>
                    Payment Mode
                  </span>

                  <strong>
                    Credit
                  </strong>

                </div>

              </td>

            </tr>

          </tbody>

        </table>

        {/* CUSTOMER / SUPPLIER */}

        <table className="invoice-table">

          <tbody>

            <tr>

              <td>

                <div className="section-title">

                  Buyer / Supplier

                </div>

                <div className="buyer-name">

                  {

                    invoiceData.buyerName

                  }

                </div>

                <div className="company-text">

                  GSTIN:
                  {" "}

                  {

                    invoiceData.buyerGSTIN
                  }

                </div>

              </td>

            </tr>

          </tbody>

        </table>

        {/* ITEMS */}

        <table className="items-table">

          <thead>

            <tr>

              <th>Sl</th>

              <th>Description</th>

              <th>HSN</th>

              <th>Qty</th>

              <th>Rate</th>

              <th>GST %</th>

              <th>Amount</th>

            </tr>

          </thead>

          <tbody>

            {

              items.map(

                (item, index) => {

                  const calc =

                    calculateItem(
                      item
                    )

                  return (

                    <tr key={index}>

                      <td>
                        {index + 1}
                      </td>

                      <td>
                        {item.description}
                      </td>

                      <td>
                        {item.hsn}
                      </td>

                      <td>
                        {item.quantity}
                      </td>

                      <td>
                        ₹{item.rate}
                      </td>

                      <td>
                        {item.gstRate}%
                      </td>

                      <td>

                        ₹{

                          calc.total
                            .toFixed(2)

                        }

                      </td>

                    </tr>
                  )
                }
              )
            }

          </tbody>

        </table>

        {/* TOTALS */}

        <div className="totals-section">

          <div className="totals-box">

            <div className="total-row">

              <span>
                Taxable Value
              </span>

              <span>

                ₹{

                  subtotal.toFixed(2)

                }

              </span>

            </div>

            <div className="total-row">

              <span>
                CGST
              </span>

              <span>

                ₹{

                  cgst.toFixed(2)

                }

              </span>

            </div>

            <div className="total-row">

              <span>
                SGST
              </span>

              <span>

                ₹{

                  sgst.toFixed(2)

                }

              </span>

            </div>

            <div className="total-row grand-total">

              <span>
                Grand Total
              </span>

              <span>

                ₹{

                  grandTotal.toFixed(2)

                }

              </span>

            </div>

          </div>

        </div>

        {/* DECLARATION */}

        <div className="declaration-box">

          <strong>
            Declaration
          </strong>

          <p>

            We declare that this invoice
            reflects the actual value of
            goods/services supplied and
            all details mentioned are
            true and correct.

          </p>

        </div>

        {/* FOOTER */}

        <div className="invoice-footer">

          <div>

            Company's Bank Details

            <br /><br />

            A/c Holder:
            {" "}

            {

              companyData.companyName

              ||

              "-"
            }

            <br />

            Bank:
            {" "}
            HDFC Bank

            <br />

            A/c No:
            {" "}
            XXXXXXXXXX

            <br />

            IFSC:
            {" "}
            HDFC000123

          </div>

          <div className="signature-box">

            for
            {" "}

            {

              companyData.companyName

              ||

              "Company"
            }

            <br /><br /><br /><br />

            Authorised Signatory

          </div>

        </div>

      </div>

    </div>
  )
}